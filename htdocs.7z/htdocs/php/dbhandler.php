<?php
$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "users";

$conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);